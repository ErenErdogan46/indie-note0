import Header from "@/components/header";
import Footer from "@/components/footer";
import { Mail, MessageSquare, Globe, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Contact() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Contact Us</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Have questions, suggestions, or need help? We'd love to hear from you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-5 h-5 mr-2" />
                  Send us a message
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">
                      Name
                    </label>
                    <Input id="name" placeholder="Your name" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="your@email.com" />
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-1">
                      Subject
                    </label>
                    <Input id="subject" placeholder="What's this about?" />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">
                      Message
                    </label>
                    <Textarea 
                      id="message" 
                      placeholder="Tell us more..."
                      className="min-h-[120px]"
                    />
                  </div>
                  <Button className="w-full">Send Message</Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Email Support</h3>
                    <p className="text-slate-600 text-sm mb-2">
                      For general inquiries and support
                    </p>
                    <a href="mailto:support@indie-note.com" className="text-primary hover:underline">
                      support@indie-note.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Globe className="w-6 h-6 text-secondary mt-1" />
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Community</h3>
                    <p className="text-slate-600 text-sm mb-2">
                      Join our community discussions
                    </p>
                    <a href="#" className="text-secondary hover:underline">
                      Community Forum
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <AlertTriangle className="w-6 h-6 text-red-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-red-800 mb-1">Copyright Issues</h3>
                    <p className="text-red-700 text-sm mb-2">
                      Report copyright violations or content disputes
                    </p>
                    <a href="mailto:copyright@indie-note.com" className="text-red-600 hover:underline">
                      copyright@indie-note.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-slate-100 rounded-xl p-6">
              <h3 className="font-semibold text-slate-900 mb-3">Response Time</h3>
              <ul className="space-y-2 text-sm text-slate-600">
                <li>• General inquiries: 1-2 business days</li>
                <li>• Technical support: 24-48 hours</li>
                <li>• Copyright issues: Within 24 hours</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-3">Before You Upload</h3>
          <div className="text-yellow-700 text-sm space-y-2">
            <p>
              <strong>Remember:</strong> You are solely responsible for ensuring all uploaded content complies with copyright laws.
            </p>
            <p>
              Only share materials that are:
            </p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Your original work</li>
              <li>Content you have explicit permission to share</li>
              <li>Materials in the public domain</li>
              <li>Content covered under fair use (check local laws)</li>
            </ul>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
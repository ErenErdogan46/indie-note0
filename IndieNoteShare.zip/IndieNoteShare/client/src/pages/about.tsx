import Header from "@/components/header";
import Footer from "@/components/footer";
import { BookOpen, Users, Globe, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">About indie-note</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Connecting students worldwide through shared knowledge and educational resources
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center mb-4">
              <BookOpen className="w-8 h-8 text-primary mr-3" />
              <h3 className="text-xl font-semibold text-slate-900">Our Mission</h3>
            </div>
            <p className="text-slate-600">
              To democratize access to quality educational materials by creating a global platform where university students can share and access notes in multiple languages.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center mb-4">
              <Globe className="w-8 h-8 text-secondary mr-3" />
              <h3 className="text-xl font-semibold text-slate-900">Global Reach</h3>
            </div>
            <p className="text-slate-600">
              Supporting students across different cultures and languages with content available in English, German, Turkish, and Hindi.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center mb-4">
              <Users className="w-8 h-8 text-accent mr-3" />
              <h3 className="text-xl font-semibold text-slate-900">Community Driven</h3>
            </div>
            <p className="text-slate-600">
              Built by students, for students. Our platform thrives on the generosity and collaboration of our academic community.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center mb-4">
              <Heart className="w-8 h-8 text-red-500 mr-3" />
              <h3 className="text-xl font-semibold text-slate-900">Support Creators</h3>
            </div>
            <p className="text-slate-600">
              Direct integration with Buy Me a Coffee allows students to support content creators who share valuable educational materials.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-8 shadow-sm border border-slate-200 mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h4 className="font-semibold text-slate-900 mb-2">Share</h4>
              <p className="text-slate-600 text-sm">Upload your university notes with Google Drive links</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-secondary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h4 className="font-semibold text-slate-900 mb-2">Discover</h4>
              <p className="text-slate-600 text-sm">Browse notes by subject and language</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-accent text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h4 className="font-semibold text-slate-900 mb-2">Support</h4>
              <p className="text-slate-600 text-sm">Show appreciation through Buy Me a Coffee</p>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-3">Important Legal Notice</h3>
          <p className="text-yellow-700 text-sm leading-relaxed">
            <strong>Copyright Responsibility:</strong> Users are solely responsible for ensuring that all uploaded content is either their original work or content they have explicit permission to share. indie-note does not take responsibility for copyright infringement. By uploading materials, you confirm that you own the rights to the content or have obtained proper authorization for sharing. We reserve the right to remove any content that violates copyright laws.
          </p>
        </div>
      </main>

      <Footer />
    </div>
  );
}
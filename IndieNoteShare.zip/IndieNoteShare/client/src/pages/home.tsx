import { useState } from "react";
import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import MainNavigation from "@/components/main-navigation";
import PostCard from "@/components/post-card";
import Footer from "@/components/footer";
import { useQuery } from "@tanstack/react-query";
import type { Post } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all");
  const [selectedSubject, setSelectedSubject] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const { data: posts, isLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts", selectedLanguage, selectedSubject, searchQuery],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedLanguage !== "all") params.append("language", selectedLanguage);
      if (selectedSubject !== "all") params.append("subject", selectedSubject);
      if (searchQuery) params.append("search", searchQuery);
      
      const response = await fetch(`/api/posts?${params}`);
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    },
  });

  const getLanguages = () => [
    { key: "all", label: "All Languages" },
    { key: "english", label: "English" },
    { key: "german", label: "Deutsch" },
    { key: "turkish", label: "Türkçe" },
    { key: "hindi", label: "हिन्दी" },
  ];

  const getSubjects = () => [
    { key: "all", label: "All Subjects" },
    { key: "computer-science", label: "Computer Science" },
    { key: "medicine", label: "Medicine" },
    { key: "engineering", label: "Engineering" },
    { key: "business", label: "Business" },
    { key: "mathematics", label: "Mathematics" },
    { key: "physics", label: "Physics" },
    { key: "chemistry", label: "Chemistry" },
    { key: "biology", label: "Biology" },
    { key: "psychology", label: "Psychology" },
    { key: "economics", label: "Economics" },
    { key: "law", label: "Law" },
  ];

  const filteredPosts = posts || [];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <HeroSection />
      <MainNavigation
        selectedLanguage={selectedLanguage}
        onLanguageChange={setSelectedLanguage}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedSubject={selectedSubject}
        onSubjectChange={setSelectedSubject}
        languages={getLanguages()}
        subjects={getSubjects()}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">
            University Course Notes
          </h3>
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <h4 className="text-sm font-medium text-slate-700 mb-3">Filter by Language</h4>
              <div className="flex flex-wrap gap-2">
                {getLanguages().map((language) => (
                  <button
                    key={language.key}
                    onClick={() => setSelectedLanguage(language.key)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      selectedLanguage === language.key
                        ? "bg-primary text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {language.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-slate-700 mb-3">Filter by Subject</h4>
              <div className="flex flex-wrap gap-2">
                {getSubjects().map((subject) => (
                  <button
                    key={subject.key}
                    onClick={() => setSelectedSubject(subject.key)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      selectedSubject === subject.key
                        ? "bg-secondary text-white"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {subject.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Skeleton className="w-10 h-10 rounded-full" />
                    <div>
                      <Skeleton className="h-4 w-24 mb-1" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-20 rounded-full" />
                </div>
                <Skeleton className="h-5 w-full mb-3" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4 mb-4" />
                <div className="flex justify-between mb-4">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <div className="flex space-x-3">
                  <Skeleton className="h-10 flex-1" />
                  <Skeleton className="h-10 w-16" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-slate-400 text-6xl mb-4">📚</div>
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              No notes found
            </h3>
            <p className="text-slate-500">
              No notes have been shared yet. Be the first to share!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onDonate={() => {}}
              />
            ))}
          </div>
        )}

        {filteredPosts.length > 0 && (
          <div className="flex justify-center mt-12">
            <button className="bg-slate-100 text-slate-700 px-8 py-3 rounded-lg hover:bg-slate-200 transition-colors font-medium">
              Load More
            </button>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

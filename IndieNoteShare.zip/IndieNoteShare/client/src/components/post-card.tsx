import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Post } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Download, Coffee, Heart, FileText } from "lucide-react";

interface PostCardProps {
  post: Post;
  onDonate: () => void;
}

export default function PostCard({ post, onDonate }: PostCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const downloadMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/download`);
      return response.json();
    },
    onSuccess: (data) => {
      // Open Google Drive link in new tab
      window.open(data.driveLink, "_blank");
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Download started!",
        description: "File opened in new tab.",
      });
    },
    onError: () => {
      toast({
        title: "Error!",
        description: "An error occurred during download.",
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/like`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const handleDownload = () => {
    downloadMutation.mutate(post.id);
  };

  const handleLike = () => {
    likeMutation.mutate(post.id);
  };

  const getSubjectColor = (subject: string) => {
    const colors = {
      "Computer Science": "bg-blue-100 text-blue-700",
      "Medicine": "bg-red-100 text-red-700",
      "Engineering": "bg-orange-100 text-orange-700",
      "Business": "bg-green-100 text-green-700",
      "Mathematics": "bg-purple-100 text-purple-700",
      "Physics": "bg-indigo-100 text-indigo-700",
      "Chemistry": "bg-pink-100 text-pink-700",
      "Biology": "bg-emerald-100 text-emerald-700",
      "Psychology": "bg-yellow-100 text-yellow-700",
      "Economics": "bg-teal-100 text-teal-700",
      "Law": "bg-gray-100 text-gray-700",
    };
    return colors[subject as keyof typeof colors] || "bg-slate-100 text-slate-700";
  };

  const getInitialsColor = (initials: string) => {
    const colors = [
      "from-primary to-blue-600",
      "from-secondary to-green-600",
      "from-red-500 to-pink-600",
      "from-indigo-500 to-purple-600",
      "from-yellow-500 to-orange-600",
    ];
    const index = initials.charCodeAt(0) % colors.length;
    return colors[index];
  };



  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 bg-gradient-to-br ${getInitialsColor(post.creatorInitials)} rounded-full flex items-center justify-center text-white font-semibold`}>
            <span>{post.creatorInitials}</span>
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">{post.creatorName}</h4>
            <p className="text-sm text-slate-500">
              {post.createdAt ? new Date(post.createdAt).toLocaleDateString("tr-TR") : "Yeni"}
            </p>
          </div>
        </div>
        <div className="flex flex-col items-end space-y-1">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSubjectColor(post.subject)}`}>
            {post.subject}
          </span>
          <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {post.language}
          </span>
        </div>
      </div>
      
      <h3 className="text-lg font-semibold text-slate-900 mb-3">{post.title}</h3>
      <p className="text-slate-600 mb-4 line-clamp-3">{post.description}</p>
      
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4 text-sm text-slate-500">
          <span className="flex items-center">
            <Download className="w-4 h-4 mr-1" />
            {post.downloads || 0} downloads
          </span>
          <button 
            onClick={handleLike}
            className="flex items-center hover:text-red-500 transition-colors"
            disabled={likeMutation.isPending}
          >
            <Heart className="w-4 h-4 mr-1" />
            {post.likes || 0} likes
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <FileText className="w-4 h-4 text-red-500" />
          <span className="text-sm text-slate-500">{post.fileSize}</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        <Button
          onClick={handleDownload}
          disabled={downloadMutation.isPending}
          className="flex-1 bg-primary text-white hover:bg-blue-600"
        >
          <Download className="w-4 h-4 mr-2" />
          {downloadMutation.isPending ? "Downloading..." : "Download"}
        </Button>
        {post.buyMeCoffeeLink && (
          <Button
            onClick={() => window.open(post.buyMeCoffeeLink, "_blank")}
            className="bg-accent text-white hover:bg-yellow-500"
          >
            <Coffee className="w-4 h-4 mr-2" />
            ☕
          </Button>
        )}
      </div>
    </div>
  );
}

import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Upload } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-primary/5 to-secondary/5 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Share & Access <span className="text-primary">University Notes</span> Globally
          </h2>
          <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
            Connect with students worldwide. Share your university notes in multiple languages, access quality materials, and support creators through donations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary text-white hover:bg-blue-600 font-semibold">
              <Search className="w-5 h-5 mr-2" />
              Browse Notes
            </Button>
            <Link href="/create">
              <Button size="lg" variant="outline" className="border-2 border-primary text-primary hover:bg-primary hover:text-white font-semibold">
                <Upload className="w-5 h-5 mr-2" />
                Share Your Notes
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

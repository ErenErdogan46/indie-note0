import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  driveLink: text("drive_link").notNull(),
  subject: text("subject").notNull(), // Computer Science, Medicine, etc.
  language: text("language").notNull(), // English, German, Turkish, Hindi
  tags: text("tags").array().default([]),
  creatorName: text("creator_name").notNull(),
  creatorInitials: text("creator_initials").notNull(),
  fileSize: text("file_size").notNull(),
  downloads: integer("downloads").default(0),
  likes: integer("likes").default(0),
  buyMeCoffeeLink: text("buy_me_coffee_link"), // Optional Buy Me a Coffee link
  createdAt: timestamp("created_at").defaultNow(),
});

export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  amount: integer("amount").notNull(),
  message: text("message"),
  donorName: text("donor_name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  downloads: true,
  likes: true,
  createdAt: true,
});

export const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  createdAt: true,
});

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type Donation = typeof donations.$inferSelect;

// Remove the old user schema as it's not needed for this application
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

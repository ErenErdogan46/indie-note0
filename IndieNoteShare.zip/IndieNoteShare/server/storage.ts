import { posts, donations, type Post, type InsertPost, type Donation, type InsertDonation, users, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  // Post operations
  getPosts(): Promise<Post[]>;
  getPostsBySubject(subject: string): Promise<Post[]>;
  getPostsByLanguage(language: string): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  updatePostDownloads(id: number): Promise<void>;
  updatePostLikes(id: number): Promise<void>;
  searchPosts(query: string): Promise<Post[]>;
  

  
  // User operations (kept for compatibility)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private posts: Map<number, Post>;
  private users: Map<number, User>;
  private currentPostId: number;
  private currentUserId: number;

  constructor() {
    this.posts = new Map();
    this.users = new Map();
    this.currentPostId = 1;
    this.currentUserId = 1;
  }

  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getPostsByLanguage(language: string): Promise<Post[]> {
    const allPosts = await this.getPosts();
    return allPosts.filter(post => post.language.toLowerCase() === language.toLowerCase());
  }

  async getPostsBySubject(subject: string): Promise<Post[]> {
    const allPosts = await this.getPosts();
    return allPosts.filter(post => post.subject.toLowerCase().includes(subject.toLowerCase()));
  }

  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const post: Post = {
      ...insertPost,
      id,
      downloads: 0,
      likes: 0,
      tags: insertPost.tags || [],
      buyMeCoffeeLink: insertPost.buyMeCoffeeLink || null,
      createdAt: new Date(),
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePostDownloads(id: number): Promise<void> {
    const post = this.posts.get(id);
    if (post) {
      post.downloads = (post.downloads || 0) + 1;
      this.posts.set(id, post);
    }
  }

  async updatePostLikes(id: number): Promise<void> {
    const post = this.posts.get(id);
    if (post) {
      post.likes = (post.likes || 0) + 1;
      this.posts.set(id, post);
    }
  }

  async searchPosts(query: string): Promise<Post[]> {
    const allPosts = await this.getPosts();
    const lowercaseQuery = query.toLowerCase();
    return allPosts.filter(post => 
      post.title.toLowerCase().includes(lowercaseQuery) ||
      post.description.toLowerCase().includes(lowercaseQuery) ||
      post.subject.toLowerCase().includes(lowercaseQuery) ||
      post.language.toLowerCase().includes(lowercaseQuery) ||
      post.tags?.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    );
  }



  // User operations (kept for compatibility)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
}

export const storage = new MemStorage();

# indie-note - University Notes Sharing Platform

## Overview

This is a full-stack web application for sharing and accessing university-level educational notes with multi-language support. The platform focuses exclusively on university courses and supports English, German, Turkish, and Hindi languages. Users can upload, browse, filter by language and subject, and support creators through donations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **UI Framework**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom configuration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API endpoints
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured for Neon/serverless)
- **Session Management**: Connect-pg-simple for PostgreSQL sessions
- **Development**: TSX for TypeScript execution

### Project Structure
- `client/` - React frontend application
- `server/` - Express backend API
- `shared/` - Shared TypeScript types and schemas
- Monorepo structure with shared dependencies

## Key Components

### Database Schema (PostgreSQL)
- **Posts Table**: Educational content with metadata
  - Basic info: title, description, subject, language
  - File management: Google Drive links, file sizes
  - Social features: downloads, likes, tags
  - Creator info: name, initials
  - Buy Me a Coffee integration: optional creator support links
  - Language support: English, German, Turkish, Hindi

### API Endpoints
- `GET /api/posts` - Fetch posts with filtering (language, subject, search)
- `GET /api/posts/:id` - Get individual post details
- `POST /api/posts` - Create new educational content
- `POST /api/posts/:id/download` - Track downloads
- `POST /api/posts/:id/like` - Handle post likes


### Storage Layer
- **Interface**: IStorage for database operations
- **Implementation**: MemStorage for development/testing
- **Production**: Drizzle ORM with PostgreSQL
- **File Storage**: Google Drive integration for document hosting

### UI Components
- Custom component library built on Shadcn/ui
- Responsive design with mobile-first approach
- Educational content cards with download/donation features
- Form components for content creation
- Modal system for donations and interactions

## Data Flow

1. **Content Creation**: Users submit educational materials via forms
2. **File Handling**: Documents stored on Google Drive with public links
3. **Database Storage**: Metadata and links stored in PostgreSQL
4. **Content Discovery**: Users browse by language and subject or search
5. **Engagement**: Download tracking and social features (likes)
6. **Creator Support**: Direct Buy Me a Coffee integration for supporting content creators

## External Dependencies

### Database & Storage
- **Neon Database**: Serverless PostgreSQL hosting
- **Google Drive**: File storage and sharing
- **Drizzle ORM**: Type-safe database operations

### UI & Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling
- **Lucide React**: Icon library
- **React Icons**: Additional icon sets

### Development Tools
- **Vite**: Fast development and building
- **TypeScript**: Type safety across the stack
- **ESBuild**: Backend bundling for production

## Deployment Strategy

### Development
- Replit-optimized with `.replit` configuration
- Hot reload enabled for both frontend and backend
- PostgreSQL module integration
- Port 5000 for local development

### Production Build
- Frontend: Vite builds static assets to `dist/public`
- Backend: ESBuild bundles server code to `dist/index.js`
- Single deployment target with static file serving
- Environment variable configuration for database

### Database Management
- Drizzle migrations in `migrations/` directory
- Schema-first approach with TypeScript types
- Push-based deployment with `db:push` command

## Changelog

- June 22, 2025: Initial setup
- June 22, 2025: Converted from YKS/University categories to university-only platform with multi-language support (English, German, Turkish, Hindi)
- June 22, 2025: Replaced fake donation system with real Buy Me a Coffee integration
- June 22, 2025: Renamed project to "indie-note", added About and Contact pages, implemented copyright responsibility disclaimers

## User Preferences

Preferred communication style: Simple, everyday language.